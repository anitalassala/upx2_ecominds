package com.upx.RD.model;

public enum StatusPost {
    DISPONIVEL,
    RESERVADO,
    VENDIDO,
    CANCELADO
}