package com.upx.RD.model;

public enum Unidade {
    KG,
    TONELADAS,
    METRO_CUBICO,
    METRO_QUADRADO,
    UNIDADE
}