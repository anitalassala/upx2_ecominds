package com.upx.RD;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RdApplicationTests {

	@Test
	void contextLoads() {
	}

}
